package com.signalvision.lab;

import android.app.Activity;
import android.hardware.*;
import android.os.Bundle;
import android.widget.*;

public class MainActivity extends Activity implements SensorEventListener {
    SensorManager sm; Sensor magSensor; TextView mag,xyz,delta,status; RadarView radar;
    float baseline=Float.NaN, total=0f;
    @Override public void onCreate(Bundle b){ super.onCreate(b); setContentView(R.layout.activity_main);
        mag=findViewById(R.id.mag); xyz=findViewById(R.id.xyz); delta=findViewById(R.id.delta);
        status=findViewById(R.id.status); radar=findViewById(R.id.radar);
        sm=(SensorManager)getSystemService(SENSOR_SERVICE);
        magSensor=sm.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD);
        if(magSensor==null) status.setText("Bu telefonda manyetometre bulunamadı.");
        else status.setText("Manyetometre hazır • telefonu yavaşça hareket ettir");
        findViewById(R.id.zero).setOnClickListener(v->{ baseline=total; radar.clearTrail(); });
    }
    @Override protected void onResume(){super.onResume();if(magSensor!=null)sm.registerListener(this,magSensor,SensorManager.SENSOR_DELAY_GAME);}
    @Override protected void onPause(){super.onPause();sm.unregisterListener(this);}
    @Override public void onSensorChanged(SensorEvent e){
        float x=e.values[0],y=e.values[1],z=e.values[2];
        total=(float)Math.sqrt(x*x+y*y+z*z); if(Float.isNaN(baseline))baseline=total;
        float d=total-baseline;
        mag.setText(String.format(java.util.Locale.US,"%.1f µT",total));
        xyz.setText(String.format(java.util.Locale.US,"X %.1f   Y %.1f   Z %.1f",x,y,z));
        delta.setText(String.format(java.util.Locale.US,"Δ %+.1f µT",d));
        radar.setSignal(x,y,z,d);
        status.setText(Math.abs(d)>20?"Belirgin manyetik değişim":"Canlı sensör verisi");
    }
    @Override public void onAccuracyChanged(Sensor s,int a){}
}