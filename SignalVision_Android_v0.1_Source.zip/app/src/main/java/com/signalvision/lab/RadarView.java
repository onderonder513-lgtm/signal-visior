package com.signalvision.lab;
import android.content.*; import android.graphics.*; import android.util.*; import android.view.*; import java.util.*;

public class RadarView extends View {
 Paint p=new Paint(1); float sx,sy,sz,d; ArrayList<PointF> trail=new ArrayList<>();
 public RadarView(Context c, AttributeSet a){super(c,a);p.setStyle(Paint.Style.STROKE);}
 public void clearTrail(){trail.clear();invalidate();}
 public void setSignal(float x,float y,float z,float delta){sx=x;sy=y;sz=z;d=delta;
   float a=(float)Math.atan2(y,x), r=Math.min(1f,Math.abs(delta)/40f);
   trail.add(new PointF(a,r)); if(trail.size()>70)trail.remove(0); invalidate();
 }
 protected void onDraw(Canvas c){super.onDraw(c);float w=getWidth(),h=getHeight(),cx=w/2,cy=h/2,R=Math.min(w,h)*.42f;
   p.setStrokeWidth(2);p.setColor(Color.rgb(18,57,74));
   for(int i=1;i<=4;i++)c.drawCircle(cx,cy,R*i/4,p);
   for(int i=0;i<8;i++){double a=i*Math.PI/4;c.drawLine(cx,cy,cx+(float)Math.cos(a)*R,cy+(float)Math.sin(a)*R,p);}
   for(int i=0;i<trail.size();i++){PointF q=trail.get(i);float rr=q.y*R;float x=cx+(float)Math.cos(q.x)*rr,y=cy+(float)Math.sin(q.x)*rr;
     int alpha=50+(int)(205f*i/Math.max(1,trail.size()));p.setColor(Color.argb(alpha,87,231,255));p.setStrokeWidth(5);c.drawPoint(x,y,p);}
   float a=(float)Math.atan2(sy,sx),rr=Math.min(1f,Math.abs(d)/40f)*R;
   p.setColor(Math.abs(d)>20?Color.rgb(255,180,94):Color.rgb(67,230,208));p.setStrokeWidth(5);
   c.drawCircle(cx+(float)Math.cos(a)*rr,cy+(float)Math.sin(a)*rr,18+Math.min(55,Math.abs(d)),p);
 }
}