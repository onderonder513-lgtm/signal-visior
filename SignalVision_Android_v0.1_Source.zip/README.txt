Signal Vision Android v0.1 source
Gerçek Android TYPE_MAGNETIC_FIELD sensörünü kullanır.
X/Y/Z, toplam µT, baseline delta ve canlı radar izi vardır.
ZERO düğmesi baseline'ı mevcut alana sıfırlar.
Sahte mesafe/derinlik/nesne tanıma yoktur.

Android Studio: projeyi aç > Gradle sync > Run veya Build APK.
Sonraki katman: gerçek Bluetooth taraması ve cihaz izinleri; UWB yalnız destekleyen cihazlarda.
